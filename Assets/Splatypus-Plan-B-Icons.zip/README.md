# Splatypus — Plan B

A separate set of 20 component icons exploring Splatypus as a possible plugin name. Plan A, its ZIP archive, and the artwork currently embedded in the plugin are preserved. No plugin renaming or icon switching is performed.

## Design

The existing tool references remain visible: green folded diagonals for FFmpeg, grey aperture facets and red feature points for COLMAP, and a blue handle with a red paint tip for Brush.

Three abstract platypus features tie the alternative together:

- **Flattened bill:** folder/document bases, import/export forms, and tool setup marks.
- **Paddle tail:** feature and point-cloud silhouettes, geometry, and the broad Brush handle.
- **Webbed foot:** triangulated reconstruction, camera rays, alignment, and the download tray.

The Hello Splat icon and the additional brand mark combine these features into a simplified platypus silhouette. The three dots above it retain the tool-family colours. Each other icon prioritizes its component action with a smaller anatomical reference. Labels still match the current plugin; Splatypus remains a provisional name.

## Files

- `svg/`: all 20 editable masters on a 24 × 24 grid.
- `png24/`, `png48/`, `png96/`: transparent PNG exports.
- `brand/`: an additional SVG and 256-pixel PNG of the proposed Splatypus mark.
- `review/splatypus-components.png`: full labelled set, including native-size light/dark previews.
- `review/plan-a-vs-b.png`: all 20 original and alternative icons side by side.
- `review/index.html`: both sheets in a local browser page.
- `manifest.json`: stable asset IDs, current component names, and motif descriptions.
- `generate.cjs`: repeatable vector and export generator. Run with Node.js and Sharp, passing the Sharp module path if needed.

The generator reads the original set for the comparison sheet; all output stays in this Plan B folder. It does not change the original set or the plugin. Artwork follows the supplied tool references and is an original interpretation, not an official logo replacement.
