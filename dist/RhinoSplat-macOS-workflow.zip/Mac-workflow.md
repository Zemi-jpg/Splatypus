# RhinoSplat macOS workflow

This is a Mac-targeted build candidate, compiled on Windows against the pinned Rhino/Grasshopper 8.34.26223.11001 SDK. It targets Rhino 8.34 or newer using .NET 8. Native Rhino/macOS integration and real Mac reconstruction/training have not yet been verified. Gaussian splat viewport rendering is excluded.

## Install the prepared package

1. Use Rhino 8 with its .NET 8 runtime. Close Rhino before copying plugin files.
2. In Grasshopper, use File > Special Folders > Components Folder to identify the actual Libraries folder. Copy `RhinoSplat.gha` and `RhinoSplat.Core.dll` from `dist/macos` together into a `RhinoSplat` subfolder there. Alternatively run `bash Install-Mac.sh "/absolute/path/to/Grasshopper/Libraries"` from this source folder.
3. Keep only one installed RhinoSplat assembly and restart Rhino. The Mac and Windows versions use the same component IDs.

## External tools

On Apple Silicon, use **01 Setup → RS Download Tools**. Leave Folder blank and connect a Button to Download. It installs pinned FFmpeg (including ffprobe) and CPU COLMAP in private environments, plus the official Brush binary, then returns executable paths for the later components. No Homebrew or system PATH changes are required. Native installation still needs Mac testing; see [Download Tools](Download-tools.md).

For live installation output on Apple Silicon, set Download Tools **Terminal=True** before Download. macOS may ask to allow Terminal automation. The component also saves a log under Tools Folder/logs and returns its path through **Log** when the attempt finishes or is cancelled.

Intel Macs do not have a published Brush 0.3.0 binary, so automatic installation currently reports that limitation. Manual installation remains available. To install FFmpeg (including ffprobe) and COLMAP with Homebrew:

```sh
brew install ffmpeg colmap
command -v ffmpeg
command -v colmap
```

Paste the full executable paths into Grasshopper. Typical locations are `/opt/homebrew/bin` on Apple Silicon and `/usr/local/bin` on Intel. Do not paste the `.app` directory. For Brush, use a native executable from the official release or build the CLI from source, and use its full executable path. Check `brush --help` for the installed version. This integration expects a dataset positional argument and `--total-steps`, `--export-path`, `--export-name`, and optional `--with-viewer`.

References: [FFmpeg package](https://formulae.brew.sh/formula/ffmpeg), [COLMAP package](https://formulae.brew.sh/formula/colmap), [Brush builds and CLI](https://github.com/ArthurBrussee/brush).

## Connect the workflow

1. **RS Project** creates the project folders.
2. **RS FFmpeg Setup → RS Media Import** estimates frames and imports photographs/video into `images`. `ffprobe` must be beside the selected `ffmpeg`. Use Refresh Estimate after changing a source folder's contents. Run and Cancel remain background operations.
3. **RS COLMAP Setup → Feature Extraction → Exhaustive Matching → Sparse Mapper** reconstructs the cameras and sparse points. Run each stage after the previous stage succeeds. On macOS extraction and matching use CPU options discovered from the installed COLMAP command help, supporting both legacy Sift and newer Feature option names.
4. **Model Export / Analyzer → Camera Planes / Sparse Point Cloud / Model Alignment / Geometry Translator** provide the existing inspection and alignment tools. Ordinary Rhino geometry previews remain available.
5. **Image Undistorter → Training Dataset Check → Brush Dataset** prepares corrected training images. Connect the Undistorted Workspace to Brush Dataset and disconnect its Sparse override so camera calibration stays paired with the images. Image folders are symbolic links; keep the source workspace available on a filesystem supporting links.
6. **RS Brush Train** starts training and exports PLY files under `output/<job name>`. Start with Viewer=False and Rotate for Visualization=False. Cancellation retains existing checkpoints. Open Brush Viewer is optional and external to Rhino.

Show Terminal opens macOS Terminal following the on-disk log. If macOS prevents Terminal automation, use the component Log output or open the log manually; processing still continues.

7. **RS Splat Preview** loads a Brush binary little-endian PLY as a colored Rhino point cloud. Connect the exported PLY file path to PLY; Max limits the sampled points (150,000 by default). Colors come from the splats' base color coefficients. Coordinates are preserved exactly as stored in the selected file. Lower Max for faster viewport interaction.

The Gaussian splat renderer is absent from this build. Point-cloud preview shows colored splat centers without Gaussian shape, transparency, or view-dependent shading. The existing optional PLY rotation is a file conversion only.

## Build on a Mac

Install the .NET 8 SDK and Rhino 8, then:

```sh
bash Build-Mac.sh
```

The script restores the pinned 8.34 SDK from NuGet, builds `RhinoSplat.Grasshopper.Mac.csproj`, and writes `dist/macos`. The first restore requires internet access. Build references are independent of the locally installed Rhino version. No Windows Desktop framework is required. The renderer project is not built.

## Verification

Windows: both Grasshopper targets compile without warnings/errors; 6 platform validation checks, 12 dataset/source-preservation checks and 18 background training/cancellation/export checks pass. These do not verify native macOS execution.

Repeat the portable tests on the Mac:

```sh
dotnet run --project Tests/RhinoSplat.Platform.SmokeTest.csproj
dotnet run --project Tests/RhinoSplat.BrushDataset.SmokeTest.csproj
dotnet run --project Tests/RhinoSplat.BrushBackground.SmokeTest.csproj
```

Then run a small overlapping photo set through all seven stages above. Check camera/point-cloud previews, alignment, undistorted image/model pairing, Brush PLY export, colored splat point-cloud preview, cancellation, and optional live logs. Record Rhino, macOS, COLMAP and Brush versions before treating this candidate as validated for that machine.
