# RhinoSplat for Windows — testing package

Requires Rhino 8.34 (8.34.26223.11001) or newer running .NET 8 on Windows. Built against the pinned 8.34 SDK so the package does not require the build machine's newer 8.35 SDK.

## Installation

1. Extract the ZIP. If Windows shows an Unblock checkbox in the ZIP's Properties, unblock it before extracting.
2. In Grasshopper, open File > Special Folders > Components Folder.
3. Close Rhino.
4. Create a RhinoSplat subfolder in that Components Folder and copy BOTH RhinoSplat.gha and RhinoSplat.Core.dll into it. Replace both files together when updating. Avoid keeping another installed copy of RhinoSplat elsewhere in the Components Folder.
5. Restart Rhino and open Grasshopper. Look for the RhinoSplat tab.

## Tools and workflow

Use **01 Setup → RS Download Tools**. Leave Folder blank and connect a Button to Download. It installs pinned FFmpeg (including ffprobe), COLMAP and Brush in the background. Connect the FFmpeg, COLMAP and Brush path outputs to the later components' Exe inputs. Set CUDA=False for CPU COLMAP; CUDA=True requires an NVIDIA CUDA GPU. Ready is True when all three tools validate. Existing manual tool paths remain supported.

RS Project > FFmpeg Setup / Media Import > COLMAP Setup / Feature Extraction / Exhaustive Matching / Sparse Mapper > Model Export / Analyzer / Alignment > Image Undistorter > Brush Dataset > Brush Train.

Set Download Tools **Terminal=True** before pressing Download to view installation progress live. The **Log** output returns the saved log after completion or cancellation. Closing the terminal does not cancel the installation.

Run each reconstruction stage after the preceding stage succeeds. Use the Undistorted Workspace input of Brush Dataset with Sparse disconnected to keep corrected images paired with their camera model. Use Buttons for background import/training Run and Cancel.

RS Splat Preview loads a Brush binary little-endian PLY as a colored point cloud in Rhino. Its Max input defaults to 150,000 points; reduce it for faster viewport interaction. It preserves the coordinates stored in the selected file.

This ZIP contains the Grasshopper workflow and colored point-cloud preview. It does not include a separate Gaussian splat renderer or third-party Rhino rendering plugin.

## Validation

Release build completed with zero warnings and errors. Test on the recipient's Rhino installation with a small dataset before a large training job.
